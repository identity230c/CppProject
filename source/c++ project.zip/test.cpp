
#include<iostream>


#include "position.h"

#include "box.h"

#include "game.h"
#include "mapContainer.h"

using namespace std;



void f(int x[][7], int hang) {

	int** tmp /*=  new int * [hang]*/;

	tmp = new int* [hang];



	for (int i = 0; i < hang; i++) {

		tmp[i] = new int[7];

	}

	tmp[1][1] = x[1][1];

	printf("%d\n", tmp[1][1]);

	/*for(int i=0;i<hang;i++){

		delete[] tmp[i];

	}

	delete[] *tmp;*/

}


int main() {

	Position p1(1, 3), p2;

	cout << p1.x << " " << p1.y << endl;

	//Position �׽�Ʈ

	int arr[5][7] = {};

	arr[1][1] = 104729;

	f(arr, 5);

	Box b;

	b = Box(3, 4);

	p2 = b.getPosition();

	cout << p2.x << " " << p2.y << endl;

	b.setPosition(p1);

	p2 = b.getPosition();

	cout << p2.x << " " << p2.y << endl;

	p2 = b.move(1);

	cout << p2.x << " " << p2.y << endl;

	cout << "���� �׽�Ʈ" << endl;

	mapContainer map;
	while(map.mapindex != 5){
	Game g(map.getMap());

	for (int i = 0; i < 9; i++) {

		for (int j = 0; j < 7; j++) {

			cout << g.at(i, j) << " ";

		}

		cout << "\n";

	}

	g.printForDebug();

	cout << g.isWin() << endl;

	cout << "�������� ���� ���� --------------\n";

	while (!g.isWin()) {

		int vector;

		cin >> vector;//�¿��ϻ�

		if (g.move(g.getChar(), vector)) {

			cout << "������\n";

		}
		else {

			cout << "�� ������\n";

		}

		for (int i = 0; i < 9; i++) {

			for (int j = 0; j < 7; j++) {

				cout << g.at(i, j) << " ";

			}

			cout << "\n";

		}

		if (g.isWin()) {

			cout << "����\n";
			map.getNextMap();

		}
		else {

			cout << "���� �ȳ���\n";

		}

		g.printForDebug();

	}
	}

	return 0;

}
